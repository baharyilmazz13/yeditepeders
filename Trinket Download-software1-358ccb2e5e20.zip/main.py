#SOFTWAREFİRMA
note=int(input("Deine Note:"))
if note>80:
  print("Ja")
else:
  print("Nein")
a=int(input("Deine Jahren:"))
if 20<=a<=50:
  print("Einstellen")
else:
  print("Ablehnen")